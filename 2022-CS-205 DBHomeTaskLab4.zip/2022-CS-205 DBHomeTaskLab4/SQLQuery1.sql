USE [Northwind]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*Q1*/
SELECT [ProductName] FROM Products WHERE UnitPrice > (SELECT AVG(UnitPrice) FROM Products) ;
/*Q2*/
SELECT [ShippedDate],COUNT(*) AS NumberOfOrders FROM Orders GROUP BY ShippedDate ORDER BY ShippedDate asc ;
/*Q3*/
SELECT [Country] FROM Suppliers GROUP BY Country HAVING COUNT(Country) >= 2 ORDER BY Country desc;
/*Q4*/
SELECT MONTH(ShippedDate) AS monthNumber,COUNT(*) AS NoOfDelayedOrder FROM Orders WHERE ShippedDate>RequiredDate GROUP BY MONTH(ShippedDate)
ORDER BY monthNumber asc;
/*Q5*/
SELECT [OrderID],SUM(Discount) AS TotalDiscount FROM [Order Details] WHERE Discount > 0 GROUP BY OrderID ORDER BY OrderID asc;
/*Q6*/
SELECT [ShipCity],COUNT(*) AS NumberOfOrders FROM Orders WHERE ShipCountry = 'USA' AND YEAR(ShippedDate) = 1997 GROUP BY ShipCity 
ORDER BY ShipCity asc ;
/*Q7*/
SELECT [ShipCountry],COUNT(*) AS OrderDelayed FROM Orders WHERE ShippedDate>RequiredDate GROUP BY ShipCountry ORDER BY ShipCountry asc ;
/*Q8*/
SELECT [OrderID],SUM(Discount) AS TotalDiscount ,SUM(UnitPrice) AS TotalPrice  FROM [Order Details] WHERE Discount > 0 GROUP BY OrderID 
ORDER BY OrderID asc;
/*Q9*/
SELECT [ShipCity],[ShipRegion],COUNT(*) AS NumberOfOrders FROM Orders WHERE YEAR(ShippedDate) = 1997 GROUP BY 
ShipRegion,ShipCity ORDER BY ShipRegion asc ;
